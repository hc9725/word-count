#ifndef GETWORDSTDIN_H
#define GETWORDSTDIN_H	
#include <string.h>
#include <stdio.h>
#include "dbllink.h"
#include "wordinsert.h"
//void getwordstdin(int uptolower,Dlinklist list);
void getwordstdin(int uptolower,Dlinklist list,char cnt);

#endif

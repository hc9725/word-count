#include "getword.h"

void getword(FILE *fp, int uptolower, Dlinklist list,char cnt)
//void getword(FILE *fp, int uptolower, Dlinklist list)
{
	char c;
	int islistempty=1;
	static int  ipro = 0;
	char  cnext;
	char  cnnext;
	static int  i = 0;
	int len = 0;
	char   ss[256];
	char *sss = ss;
	c = fgetc(fp);
//	printf("%d",uptolower);
	while(c != EOF)
	{
		if((c == '\\'|| c== '-') && ipro ==1)
		{
			
			 if((cnext = fgetc(fp)) == EOF)
			{
				//len = strlen(ss);
				//if(len > 0)
				if(ipro ==1)
				{
					ss[i++] = '\0';
					//wordinsert(list,ss);
					wordinsert(list,ss,islistempty,cnt);
					islistempty = 0;
				}
				exit(0);
			}	
			if(cnext == 'u')
			{
					
				 if((cnnext = fgetc(fp)) == EOF)
				{
					//len = strlen(ss);
					//if(len > 0)
					if(ipro ==1)
					{
						ss[i++] = '\0';
						//wordinsert(list,ss);
						//wordinsert(list,ss,islistempty);
						wordinsert(list,ss,islistempty,cnt);
						islistempty = 0;
					}
					exit(0);
				}	
				if((cnnext >= '0' && cnnext <= '9') || (cnnext>= 'a' && cnnext<= 'z')||\
				(cnnext>= 'A' && cnnext <= 'Z'))
				{
					//ss[i++] = c;
					//printf("%c",cnnext);
					if(uptolower == 1)
					{
						if(cnnext >= 'A' && cnnext <=  'Z')
						{
							ss[i++] = cnnext + 32;
						}
						else
						{
							ss[i++] = cnnext;
				//			printf("%c",cnnext);
						}
					}
					else 
					{
				//		printf("%c",cnnext);
						ss[i++] = cnnext;
					}
					ipro =1;
				}
				else 
				{
					ss[i++] = '\0';
					//printf("%s ",ss);
					//len = strlen(ss);
					//if(len > 0)
					if(ipro == 1)
					{
						//wordinsert(list,ss);
						wordinsert(list,ss,islistempty,cnt);
						islistempty = 0;
					}
					ipro = 0;
					ss[0] = '\0';
					i = 0;
				}

			}
		}
		else if(c == '\'' && ipro == 1)
		{
			 if((cnext = fgetc(fp)) == EOF)
			 {  
				//len = strlen(ss);
				//if(len > 0)
				if(ipro ==1 )
					{
						ss[i++] = '\0';
						//wordinsert(list,ss);
						wordinsert(list,ss,islistempty,cnt);
						islistempty = 0;
					}
			 	exit(0);
			 }
			
			else 
			{
				if((cnext >= '0' && cnext <= '9') || (cnext >= 'a' && cnext <= 'z')|| (cnext >= 'A' && cnext <= 'Z'))
				{	
				//	printf("%c",c);
					ss[i++]=c;
					if(uptolower ==1)
					{
						if(cnext >= 'A' && cnext <= 'Z')
						{
				//			printf("%c",cnext);
							ss[i++] = cnext + 32;
						}
						else 
						{
				//			printf("%c",cnext);
							ss[i++] = cnext;
						}
					}
					else
					{
				//		printf("%c",cnext);
						ss[i++]=cnext;
					}
					ipro = 1;
				}
				else 
				{
					ipro = 0;
					continue;
				}
			}
		}
		else if((c >= '0' && c <= '9') || (c>= 'a' && c<= 'z')|| (c>= 'A' && c <= 'Z'))
		{
			//printf("%c ",c);
			if(uptolower == 1)
			{
				if(c >= 'A' && c <= 'Z')
				{
				//	printf("%c",c);
					ss[i++] = c + 32;
				}
				else 
				{
				//	printf("%c",c);
					ss[i++] = c;
				}
			}
			else
			{
				//printf("%c",c);
				ss[i++] = c;
			}
			ipro = 1;
			//printf("blbl");
		}
		else 
		{	if(ipro == 1)
			{
				ss[i++] = '\0';
				//printf("%s ", ss);
			//	wordinsert(list,ss);
				wordinsert(list,ss,islistempty,cnt);
				islistempty = 0;
				ss[0] ='\0' ;
				ipro = 0;
				i = 0;
			}
			else 
			{
				ipro = 0;
			}
		}
		
		c = fgetc(fp);
	}
//	len = strlen(ss);
//	if(len > 0)
	if(ipro ==1 )
	{
		ss[i++] = '\0';
	//	wordinsert(list,ss);
		wordinsert(list,ss,islistempty,cnt);
		islistempty = 0;
	}
}

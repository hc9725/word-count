#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include "dbllink.h"
#include "wordinsert.h"

//void getword(FILE *fp,int uptolower,Dlinklist list);
void getword(FILE *fp,int uptolower,Dlinklist list,char cnt);

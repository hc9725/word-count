#include <stdio.h>
main()
{


int i = strcmp("a","a");
printf("%d",i);
}

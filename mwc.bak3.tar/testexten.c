#include <stdio.h>
static int a ;
main()
{
	a=22;
	printf("test here\n");
	test1();
}

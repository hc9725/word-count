#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main()
{
	int uptolower = 1;
	FILE *fp = fopen("harrypoter/phoenix.txt","r");
	char c;
	static int  ipro = 0;
	char  cnext;
	char  cnnext;
	static int  i = 0;
	int len = 0;
	char   ss[256];
	char *sss = ss;
	c = fgetc(fp);
//	printf("%d",uptolower);
	while(c != EOF)
	{
		if((c == '\\'|| c== '-') && ipro ==1)
		{
			
			 if((cnext = fgetc(fp)) == EOF)
			{
				len = strlen(ss);
				if(len > 0)
				{
					ss[i++] = '\0';
					printf("%s\n",ss);	
					//wordinsert(list,ss);
				}
				exit(0);
			}	
			if(cnext == 'u')
			{
					
				 if((cnnext = fgetc(fp)) == EOF)
				{
					len = strlen(ss);
					if(len > 0)
					{
						ss[i++] = '\0';
						printf("%s\n",ss);	
					//	wordinsert(list,ss);
					}
					exit(0);
				}	
				if((cnnext >= '0' && cnnext <= '9') || (cnnext>= 'a' && cnnext<= 'z')||\
				(cnnext>= 'A' && cnnext <= 'Z'))
				{
					//ss[i++] = c;
					//printf("%c",cnnext);
					if(uptolower == 1)
					{
						if(cnnext >= 'A' && cnnext <=  'Z')
						{
							ss[i++] = cnnext + 32;
						}
						else
						{
							ss[i++] = cnnext;
				//			printf("%c",cnnext);
						}
					}
					else 
					{
				//		printf("%c",cnnext);
						ss[i++] = cnnext;
					}
					ipro =1;
				}
				else 
				{
					ss[i++] = '\0';
					//printf("%s ",ss);
					len = strlen(ss);
					if(len > 0)
					{

					printf("%s\n",ss);	
					//	wordinsert(list,ss);
					}
					ipro = 0;
					ss[0] = '\0';
					i = 0;
				}

			}
		}
		else if(c == '\'' && ipro == 1)
		{
			 if((cnext = fgetc(fp)) == EOF)
			 {  
				len = strlen(ss);
				if(len > 0)
					{
						ss[i++] = '\0';
					printf("%s\n",ss);	
					//	wordinsert(list,ss);
					}
			 	exit(0);
			 }
			
			else 
			{
				if((cnext >= '0' && cnext <= '9') || (cnext >= 'a' && cnext <= 'z')|| (cnext >= 'A' && cnext <= 'Z'))
				{	
				//	printf("%c",c);
					ss[i++]=c;
					if(uptolower ==1)
					{
						if(cnext >= 'A' && cnext <= 'Z')
						{
				//			printf("%c",cnext);
							ss[i++] = cnext + 32;
						}
						else 
						{
				//			printf("%c",cnext);
							ss[i++] = cnext;
						}
					}
					else
					{
				//		printf("%c",cnext);
						ss[i++]=cnext;
					}
					ipro = 1;
				}
				else 
				{
					ipro = 0;
					continue;
				}
			}
		}
		else if((c >= '0' && c <= '9') || (c>= 'a' && c<= 'z')|| (c>= 'A' && c <= 'Z'))
		{
			//printf("%c ",c);
			if(uptolower == 1)
			{
				if(c >= 'A' && c <= 'Z')
				{
				//	printf("%c",c);
					ss[i++] = c + 32;
				}
				else 
				{
				//	printf("%c",c);
					ss[i++] = c;
				}
			}
			else
			{
				//printf("%c",c);
				ss[i++] = c;
			}
			ipro = 1;
			//printf("blbl");
		}
		else 
		{	if(ipro == 1)
			{
				ss[i++] = '\0';
				printf("%s\n ", ss);
			//	wordinsert(list,ss);
				ss[0] ='\0' ;
				ipro = 0;
				i = 0;
			}
			else 
			{
				ipro = 0;
			}
		}
		
		c = fgetc(fp);
	}
	len = strlen(ss);
	if(len > 0)
	{
		ss[i++] = '\0';
		printf("%s \n", ss);
	//	wordinsert(list,ss);
	}
}

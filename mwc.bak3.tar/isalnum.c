#include <ctype.h>
#include <stdio.h>

main()
{
	char a;
	while(scanf("%c",&a) != EOF )
	{
		if(isalnum(a))
		{
			printf("%c is a  alum\n",a);
			if(islower(a))
			{char b = toupper(a);

			printf("%c is now a upper case\n",b);
			}
		}
		else
		printf("it is not a digit or alpha\n");
	}

}

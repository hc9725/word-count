#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include "dbllink.h"
#include "wordinsert.h"
extern  Dlinklist list;
extern  Dlinklist listc;
extern  Dlinklist listg;
extern  Dlinklist listk;
extern  Dlinklist listo;
extern  Dlinklist lists;
extern  Dlinklist listw;

//void getword(FILE *fp,int uptolower,Dlinklist list);
//void getword(FILE *fp,int uptolower,Dlinklist list,char cnt);
void getword(FILE *fp,int uptolower,char cnt);
void wordtolist(char *ss, int islistempty,char cnt);

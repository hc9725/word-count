#include <stdio.h>
#include <string.h>
#include <stdlib.h>
aaaaaaaaa1aaaaaaaaa
typedef struct 
{
	char *aa;

}aa;
int cmp(void *a,void *b)
{
	return strcmp((const char *)a ,(const char *)b);
}
main()
{
char a[255];
char c;
int i  = 0;
char *testlen = "abcd";
printf("%c,%c \n", testlen[3],testlen[4]);
i = strlen(testlen);
printf("%d\n",i);
for(i=0;i<4;i++)
{
	printf("%d %c\n",i,testlen[i]);
}


printf("out of while\n");
while (c = getc()!= EOF)
while (scanf("%c",&c) != EOF)
{
	 if(c >= 'a' && c<= 'z' || c >= 'A' && c <='Z' || c >= '0' && c <= '9' )  
	{
		a[i++] = c;
		printf("in if\n");
	}
	else 
	{
		printf("in else\n");
		a[i++] = '\0';
		printf("%s \n",a);
		i = 0;
		a[i] = '\0';
	}

	
}
a[i++] = '\0';
printf("%s",a);
char *a = "aaa";
printf("%#8s",a);



char a = 'H';
char b =  a + 32;

printf("%c ",b);

char *a = "aaaa";
char *b = "aaaa"; 
int i = cmp(a,b);
printf("%d" ,i);



a *aaa = malloc(sizeof(a)) ;
char *b="aaaaaaa";
char c[10]="aabbbbbb\n";
aaa->aa= c;
printf("%s",b);
printf("%s",aaa->aa);


char a[10] ;
a[0] = '1';
a[1] = '\n';


char s[10]="dfd";

s[0] = '\0';
s[0] = '1';
s[1] = '1';
s[2] = '1';
s[3] = '1';
s[4] = '\0';
printf("%s",s);



}

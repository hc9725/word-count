#include <stdio.h>
#include "dbllink.h"
#include <errno.h>
void wordcount(Dlinklist list);

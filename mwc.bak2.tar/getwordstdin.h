#ifndef GETWORDSTDIN_H
#define GETWORDSTDIN_H	
#include <string.h>
#include <stdio.h>
#include "dbllink.h"
#include "wordinsert.h"
extern  Dlinklist list;
extern  Dlinklist list1;
//void getwordstdin(int uptolower,Dlinklist list);
void getwordstdin(int uptolower,char cnt);
//void getwordstdin(int uptolower,Dlinklist list,char cnt);

#endif

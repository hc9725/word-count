#include <stdio.h>
extern  a;
void test1()
{
	printf("%d\n",a);
	printf("come from test1\n");
}

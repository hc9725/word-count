#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <string.h>
#include "dbllink.h"
#include "wordinsert.h"
extern  Dlinklist list;
extern  Dlinklist listn;

//void getword(FILE *fp,int uptolower,Dlinklist list);
//void getword(FILE *fp,int uptolower,Dlinklist list,char cnt);
void getword(FILE *fp,int uptolower,char cnt);
